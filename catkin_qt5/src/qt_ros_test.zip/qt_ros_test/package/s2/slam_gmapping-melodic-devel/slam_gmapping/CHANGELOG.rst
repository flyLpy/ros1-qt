^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package slam_gmapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.4.2 (2020-10-02)
------------------

1.4.1 (2020-03-16)
------------------

1.4.0 (2019-07-12)
------------------
* update license to BSD and maintainer to ros-orphaned-packages@googlegroups.com
  since original gmapping source and ROS openslam_gmapping package has been updated to the BSD-3 license, I think we have no reason to use CC for slam_gmapping package
* Contributors: Kei Okada

1.3.10 (2018-01-23)
-------------------

1.3.9 (2017-10-22)
------------------

1.3.8 (2015-07-31)
------------------

1.3.7 (2015-07-04)
------------------

1.3.6 (2015-06-26)
------------------

1.3.5 (2014-08-28)
------------------

1.3.4 (2014-08-07)
------------------

1.3.3 (2014-06-23)
------------------

1.3.2 (2014-01-14)
------------------

1.3.1 (2014-01-13)
------------------

1.3.0 (2013-06-28)
------------------
* Renamed to gmapping, adding metapackage for slam_gmapping
* Contributors: Mike Ferguson
